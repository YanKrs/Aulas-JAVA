package br.senac.sp.model;

public enum Estado {

    CREDITO_INSUFICIENTE,
    CREDITO_SUFICIENTE,
    INICIAL,

}
