package br.senac.sp.model;

public enum Etapa {

    PESQUISANDO,
    SELECIONANDO_VOO,
    SELECIONANDO_ASSENTO,
    RESERVANDO,
    EMITINDO,
    PAGANDO

}
